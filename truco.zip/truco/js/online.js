/* ============================================================
   online.js — autenticação, salas de convite e ranking global.
   ============================================================ */

const Online = {
  client: null,
  app: null,
  user: null,
  profile: null,
  channel: null,
  activeMatchId: null,
  sdkPromise: null,

  init(app) {
    this.app = app;
    this.bind();
    this.setStatus(T.t('online_loading'));
    this.loadSdk()
      .then(() => {
        if (!window.SUPABASE_CONFIG) throw new Error(T.t('online_client_unavailable'));
        this.client = window.supabase.createClient(
          window.SUPABASE_CONFIG.url,
          window.SUPABASE_CONFIG.publishableKey
        );
        this.bindAuth();
        return this.refreshLeaderboard();
      })
      .catch((error) => this.setStatus(error.message));
  },

  loadSdk() {
    if (window.supabase && window.supabase.createClient) return Promise.resolve();
    if (this.sdkPromise) return this.sdkPromise;
    this.sdkPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
      script.async = true;
      script.onload = () => {
        if (window.supabase && window.supabase.createClient) resolve();
        else reject(new Error(T.t('online_client_unavailable')));
      };
      script.onerror = () => reject(new Error(T.t('online_client_unavailable')));
      document.head.appendChild(script);
    });
    return this.sdkPromise;
  },

  bindAuth() {
    this.client.auth.onAuthStateChange((_event, session) => {
      this.user = session ? session.user : null;
      if (!this.user) {
        this.profile = null;
        this.stopWatching();
      }
      this.renderAccount();
      setTimeout(() => {
        if (this.user) this.loadProfile().catch((error) => this.setStatus(error.message));
      }, 0);
    });
    this.client.auth.getSession()
      .then(({ data, error }) => {
        if (error) throw error;
        this.user = data.session ? data.session.user : null;
        this.renderAccount();
        if (this.user) return this.loadProfile();
        this.setStatus(T.t('online_ready'));
        return null;
      })
      .catch((error) => this.setStatus(error.message));
  },

  open() {
    if (this.client) this.refreshLeaderboard().catch((error) => this.setStatus(error.message));
  },

  bind() {
    const on = (id, fn) => {
      const button = document.getElementById(id);
      if (button) button.addEventListener('click', () => fn().catch((error) => this.setStatus(error.message)));
    };
    on('btn-online-login', () => this.signIn());
    on('btn-online-signup', () => this.signUp());
    on('btn-online-signout', () => this.signOut());
    on('btn-online-create', () => this.createRoom());
    on('btn-online-join', () => this.joinRoom());
    on('btn-online-cancel-room', () => this.cancelRoom());
    on('btn-online-close-room', async () => {
      this.stopWatching();
      this.activeMatchId = null;
      this.renderRoom(null, []);
      await this.refreshLeaderboard();
    });
    on('btn-online-refresh-ranking', () => this.refreshLeaderboard());
  },

  setStatus(message) {
    const status = document.getElementById('online-status');
    if (status) status.textContent = message || '';
  },

  renderAccount() {
    const signedIn = !!this.user;
    const auth = document.getElementById('online-auth');
    const account = document.getElementById('online-account');
    if (auth) auth.hidden = signedIn;
    if (account) account.hidden = !signedIn;
    const profile = document.getElementById('online-profile');
    if (profile) profile.textContent = signedIn
      ? (this.profile ? `${this.profile.display_name} (@${this.profile.username})` : this.user.email || '')
      : '';
  },

  async loadProfile() {
    if (!this.client || !this.user) return;
    const userId = this.user.id;
    const { data, error } = await this.client
      .from('profiles')
      .select('id, username, display_name')
      .eq('id', userId)
      .maybeSingle();
    if (error) throw error;
    if (!this.user || this.user.id !== userId) return;
    if (!data) throw new Error(T.t('online_profile_missing'));
    this.profile = data;
    this.renderAccount();
  },

  credentials() {
    const emailInput = document.getElementById('online-email');
    const passwordInput = document.getElementById('online-password');
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    if (!emailInput.checkValidity() || !passwordInput.checkValidity()) {
      (emailInput.checkValidity() ? passwordInput : emailInput).reportValidity();
      throw new Error(T.t('online_credentials_required'));
    }
    return { email, password };
  },

  async signIn() {
    if (!this.client) throw new Error(T.t('online_client_unavailable'));
    const { email, password } = this.credentials();
    this.setStatus(T.t('online_connecting'));
    const { error } = await this.client.auth.signInWithPassword({ email, password });
    if (error) throw error;
    await this.loadProfile();
    this.setStatus(T.t('online_signed_in'));
    await this.refreshLeaderboard();
  },

  async signUp() {
    if (!this.client) throw new Error(T.t('online_client_unavailable'));
    const { email, password } = this.credentials();
    const displayName = document.getElementById('online-display-name').value.trim();
    this.setStatus(T.t('online_connecting'));
    const { data, error } = await this.client.auth.signUp({
      email,
      password,
      options: { data: { display_name: displayName || 'Jogador' } },
    });
    if (error) throw error;
    if (!data.session) {
      this.setStatus(T.t('online_confirm_email'));
      return;
    }
    this.user = data.user;
    await this.loadProfile();
    this.setStatus(T.t('online_signed_in'));
    await this.refreshLeaderboard();
  },

  async signOut() {
    if (!this.client) return;
    const { error } = await this.client.auth.signOut();
    if (error) throw error;
    this.user = null;
    this.profile = null;
    this.renderAccount();
    this.setStatus(T.t('online_signed_out'));
  },

  async createRoom() {
    if (!this.client || !this.user) throw new Error(T.t('online_login_first'));
    this.setStatus(T.t('online_creating_room'));
    const variant = document.getElementById('online-variant').value;
    const { data, error } = await this.client.rpc('create_match', { p_variant: variant });
    if (error) throw error;
    const room = Array.isArray(data) ? data[0] : data;
    if (!room || !room.match_id) throw new Error(T.t('online_create_failed'));
    this.activeMatchId = room.match_id;
    await this.watchRoom(room.match_id);
    this.setStatus(T.t('online_room_created'));
  },

  async joinRoom() {
    if (!this.client || !this.user) throw new Error(T.t('online_login_first'));
    const code = document.getElementById('online-room-input').value.trim().toUpperCase();
    if (!/^[A-Z0-9]{6}$/.test(code)) throw new Error(T.t('online_invalid_code'));
    this.setStatus(T.t('online_joining_room'));
    const { data, error } = await this.client.rpc('join_match', { p_room_code: code });
    if (error) throw error;
    if (typeof data !== 'string') throw new Error(T.t('online_join_failed'));
    this.activeMatchId = data;
    await this.watchRoom(data);
    this.setStatus(T.t('online_room_joined'));
  },

  async watchRoom(matchId) {
    this.stopWatching();
    this.activeMatchId = matchId;
    const { error } = await this.refreshRoom();
    if (error) throw error;
    this.channel = this.client
      .channel(`online-match-${matchId}`)
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'matches', filter: `id=eq.${matchId}`,
      }, () => this.refreshRoom().catch((error) => this.setStatus(error.message)))
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'match_players', filter: `match_id=eq.${matchId}`,
      }, () => this.refreshRoom().catch((error) => this.setStatus(error.message)))
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          this.setStatus(T.t('online_realtime_error'));
        }
      });
  },

  stopWatching() {
    if (this.channel && this.client) {
      this.client.removeChannel(this.channel).catch((error) => this.setStatus(error.message));
    }
    this.channel = null;
  },

  async refreshRoom() {
    if (!this.client || !this.activeMatchId) return { error: null };
    const { data: match, error: matchError } = await this.client
      .from('matches')
      .select('id, room_code, created_by, status, variant, target')
      .eq('id', this.activeMatchId)
      .single();
    if (matchError) return { error: matchError };
    const { data: members, error: membersError } = await this.client
      .from('match_players')
      .select('player_id, seat, team')
      .eq('match_id', this.activeMatchId)
      .order('seat');
    if (membersError) return { error: membersError };

    const ids = members.map((member) => member.player_id);
    const { data: profiles, error: profilesError } = ids.length
      ? await this.client.from('profiles').select('id, display_name').in('id', ids)
      : { data: [], error: null };
    if (profilesError) return { error: profilesError };
    const names = new Map(profiles.map((profile) => [profile.id, profile.display_name]));
    this.renderRoom(match, members.map((member) => ({
      ...member,
      display_name: names.get(member.player_id) || T.t('online_player'),
    })));
    return { error: null };
  },

  renderRoom(match, members) {
    const room = document.getElementById('online-room');
    if (!room) return;
    room.hidden = !match;
    if (!match) return;
    document.getElementById('online-room-code').textContent = match.room_code;
    const statusKey = ['playing', 'finished', 'cancelled'].includes(match.status)
      ? `online_status_${match.status}`
      : 'online_waiting';
    const status = T.t(statusKey);
    document.getElementById('online-room-detail').textContent =
      `${T.t(match.variant)} · ${T.t('points_to', { n: match.target })} · ${status}`;
    const list = document.getElementById('online-room-players');
    list.replaceChildren();
    members.forEach((member) => {
      const row = document.createElement('li');
      row.textContent = `${member.seat + 1}. ${member.display_name}`;
      list.appendChild(row);
    });
    const cancel = document.getElementById('btn-online-cancel-room');
    cancel.hidden = match.created_by !== this.user?.id || match.status !== 'waiting';
  },

  async cancelRoom() {
    if (!this.client || !this.activeMatchId) return;
    const { error } = await this.client.rpc('cancel_match', { p_match_id: this.activeMatchId });
    if (error) throw error;
    this.stopWatching();
    this.activeMatchId = null;
    this.renderRoom(null, []);
    this.setStatus(T.t('online_room_cancelled'));
  },

  async refreshLeaderboard() {
    const list = document.getElementById('online-leaderboard');
    if (!list) return;
    list.replaceChildren();
    if (!this.client) {
      list.textContent = T.t('online_client_unavailable');
      return;
    }
    const { data, error } = await this.client
      .rpc('get_leaderboard')
      .limit(20);
    if (error) {
      list.textContent = error.message;
      return;
    }
    if (!data.length) {
      list.textContent = T.t('online_leaderboard_empty');
      return;
    }
    data.forEach((entry) => {
      const row = document.createElement('li');
      row.className = 'online__rank-row';
      const name = document.createElement('span');
      name.textContent = `${entry.position}. ${entry.display_name}`;
      const score = document.createElement('strong');
      score.textContent = `${entry.points} ${T.t('online_points')}`;
      const record = document.createElement('small');
      record.textContent = `${entry.wins} ${T.t('online_wins')} · ${entry.losses} ${T.t('online_losses')} · ${entry.matches} ${T.t('online_matches')}`;
      row.append(name, score, record);
      list.appendChild(row);
    });
  },
};

window.Online = Online;
