/* Public client credentials only. Never put a service_role or secret key here. */
window.SUPABASE_CONFIG = {
  url: 'https://qcxghnkxbkyiwsqgmham.supabase.co',
  publishableKey: 'sb_publishable_FEj8oarSFkDjKNeVYZbPHQ_lCgueUz7',
};
