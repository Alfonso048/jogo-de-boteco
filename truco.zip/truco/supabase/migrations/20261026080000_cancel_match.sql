create or replace function public.cancel_match(p_match_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_match public.matches%rowtype;
begin
  if auth.uid() is null then
    raise exception 'Você precisa entrar na sua conta.';
  end if;

  select * into v_match
  from public.matches
  where id = p_match_id
  for update;

  if not found then
    raise exception 'Sala não encontrada.';
  end if;

  if v_match.created_by <> auth.uid() then
    raise exception 'Somente quem criou a sala pode cancelá-la.';
  end if;

  if v_match.status <> 'waiting' then
    raise exception 'Só é possível cancelar uma sala que ainda está aguardando.';
  end if;

  update public.matches
  set status = 'cancelled'
  where id = p_match_id;
end;
$$;

revoke all on function public.cancel_match(uuid) from public, anon;
grant execute on function public.cancel_match(uuid) to authenticated;
