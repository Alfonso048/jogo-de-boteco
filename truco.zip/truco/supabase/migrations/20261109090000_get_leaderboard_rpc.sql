create or replace function public.get_leaderboard()
returns table (
  "position" integer,
  id uuid,
  username text,
  display_name text,
  matches integer,
  wins integer,
  losses integer,
  points integer
)
language sql
security definer
set search_path = ''
as $$
  with player_stats as (
    select
      p.id,
      p.username,
      p.display_name,
      count(m.id) filter (where m.status = 'finished'::text)::integer as matches,
      count(m.id) filter (
        where m.status = 'finished'::text and mp.team = m.winner_team
      )::integer as wins,
      count(m.id) filter (
        where m.status = 'finished'::text and mp.team <> m.winner_team
      )::integer as losses
    from public.profiles as p
    left join public.match_players as mp on mp.player_id = p.id
    left join public.matches as m
      on m.id = mp.match_id
      and m.status = 'finished'::text
    group by p.id, p.username, p.display_name
  )
  select
    row_number() over (
      order by (player_stats.wins * 3) desc,
        player_stats.wins desc,
        player_stats.display_name
    )::integer as "position",
    player_stats.id,
    player_stats.username,
    player_stats.display_name,
    player_stats.matches,
    player_stats.wins,
    player_stats.losses,
    player_stats.wins * 3 as points
  from player_stats
  order by
    (player_stats.wins * 3) desc,
    player_stats.wins desc,
    player_stats.display_name;
$$;

revoke all on function public.get_leaderboard() from public;
grant execute on function public.get_leaderboard() to anon, authenticated;
