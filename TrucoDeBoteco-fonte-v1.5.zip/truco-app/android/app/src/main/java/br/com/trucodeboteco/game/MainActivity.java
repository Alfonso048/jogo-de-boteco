package br.com.trucodeboteco.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
