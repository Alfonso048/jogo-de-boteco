#!/usr/bin/env bash
# Recompila o APK do Truco de Boteco a partir da pasta ../truco
set -e
cd "$(dirname "$0")"
export JAVA_HOME=${JAVA_HOME:-$HOME/tools/jdk21}
export ANDROID_HOME=${ANDROID_HOME:-$HOME/tools/android}
rm -rf www && cp -r ../truco www && rm -f www/GDD-Truco-de-Boteco.md
npm install
npx cap sync android
(cd android && ./gradlew assembleDebug)
cp android/app/build/outputs/apk/debug/app-debug.apk TrucoDeBoteco.apk
echo "Pronto: TrucoDeBoteco.apk"
# Release para Play Store: gerar keystore propria e rodar (cd android && ./gradlew bundleRelease)
